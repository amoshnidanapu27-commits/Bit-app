BIT Android App - ప్రారంభ ప్రాజెక్ట్

ఈ ZIP ఒక Android Studio/Cloud build source project. ఇది APK కాదు.

మొబైల్‌తో APK తయారీ:
1. ZIP ఫైల్‌ను డౌన్‌లోడ్ చేసి Extract చేయండి.
2. GitHub.com లో account సృష్టించండి లేదా sign in అవ్వండి.
3. New repository సృష్టించి ఈ ZIP లోని ఫైళ్లను upload చేయండి (అన్నీ, .github folder సహా).
4. Repository లో Actions tab తెరవండి.
5. 'Build BIT APK' workflow ఎంచుకుని Run workflow నొక్కండి.
6. Build పూర్తయ్యాక workflow run లో Artifacts కింద BIT-debug-APK డౌన్‌లోడ్ చేయండి.
7. ZIP extract చేసి app-debug.apk ను Android ఫోన్‌లో install చేయండి. అవసరమైతే Settings లో ఈ source నుంచి install అనుమతి ఇవ్వాలి.

గమనిక:
- ఇది ప్రస్తుతం offline demo WebView app మాత్రమే.
- Demo reels మాత్రమే ఉన్నాయి; login, real video upload/storage, likes/comments sync, user accounts, moderation, ads/earning ఇంకా backend తో నిర్మించాలి.
- నిజమైన users/public release కోసం privacy policy, security, reporting/moderation, Play Store requirements అవసరం.
